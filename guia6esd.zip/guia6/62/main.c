#include <stdio.h>
#include <printf.h>
#include <stdlib.h>

struct nodo{
    int info;
    struct nodo *sig;

};
struct nodo2{
    int info;
    struct nodo2 *sig;

};
struct nodo *raiz= NULL;
struct nodo2 *raiz2=NULL;

void insertar (int x){
    struct nodo *nuevo;
    nuevo = malloc(sizeof(struct nodo));
    nuevo->info =x;
    if(raiz==NULL){
        raiz=nuevo;
        nuevo->sig=NULL;
        raiz=nuevo;
    }
}
    void insertar2(int x){
    struct nodo2 *nuevo;
    nuevo= malloc(sizeof(struct nodo));
    nuevo->info=x;
    if(raiz2==NULL){
        raiz2=nuevo;
        nuevo->sig= NULL;

    }else{
        nuevo->sig = raiz2;
        raiz2=nuevo;
    }
}
void imprimir(){
    struct nodo *reco=raiz;
    printf("Pila Original. ");
    while(reco!=NULL){
        printf("  ", reco->info);
        reco= reco->sig;
    }
    printf(" ");
}
void imprimir_invertido(){
    struct nodo2 *reco=raiz2;
    printf("Pila invertida. ");
    while(reco!= NULL){
        printf("  ",reco->info);
        reco=reco->sig;

    }
    printf("\n");

}
int invertir(){
    if(raiz!= NULL){
        while(raiz!=NULL){
            struct nodo *bor=raiz;
            insertar2(bor->info);
            raiz=raiz->sig;
            free(bor);
        }
    } else{
        return -1
    }
}



int main() {
    insertar(12);
    insertar(30);
    insertar(11);
    imprimir();
    invertir();
    imprimirinvertido();


    return 0;
}